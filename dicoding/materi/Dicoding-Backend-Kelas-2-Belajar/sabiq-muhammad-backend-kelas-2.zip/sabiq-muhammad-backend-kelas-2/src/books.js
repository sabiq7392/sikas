const books = [];

module.exports = books;

// const books = [
//   {
//     title: 'Sains Number One',
//     city: 'New Yor',
//   },
//   {
//     city: 'California',
//   },
//   {
//     city: 'Jakarta',
//   },
//   {
//     title: 'JavaScript Guide',
//     city: 'Washington',
//   },
// ];

// books.forEach((book) => {
//   for (let i in book) {
//     if (i === 'title') {
//       console.log({[i]: book[i]})
//     }
//   }
// });
// const isName = books.filter((book) => book.title !== undefined);
